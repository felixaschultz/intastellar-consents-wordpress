=== Intastellar Consents Solutions ===

License:            GPL v2 or later
License URI:        https://www.gnu.org/licenses/gpl-2.0.html
Stable tag:         3.3.9
Tested up to:       6.8
Contributors:       intastellar
Requires at least:  5.8
Requires PHP:       7.4

= Short Description =
Automatically block tracking scripts and display a GDPR-compliant cookie banner.
== Description ==
This plugin loads a cookiebanner to your Wordpress site. its blocking full automatic all 3rd party cookies and scripts that a Website uses. There is no need for searching for all scripts it self.
This plugin is loading external JavaScript files, mainly the script for the Cookiebanner, from our server. This is necessary to keep the plugin up to date and to provide the best possible service.
The script is loaded on every page load, so the cookiebanner is always up to date. The script is loading the cookiebanner in the language that is set in the settings page.

The plugin loads the following external resources which are required for the consent banner to function:
JavaScript from:
https://consents.cdn.intastellarsolutions.com
CSS styling from:
https://downloads.intastellarsolutions.com
The banner and consent management logic run from these hosted resources.
Without these external files, the plugin will not display or function properly.
No personal data or WordPress user information is sent to these domains simply by loading the script.

Why are external resources required?
The consent system is centrally maintained so updates to compliance rules, UI, and consent logic can be rolled out without requiring site owners to manually update the plugin.

You can find the service on our website: https://www.intastellarsolutions.com/solutions/cookie-consents
Find the privacy policy here: https://www.intastellarsolutions.com/about/legal/privacy
Find the terms of service here: https://www.intastellarsolutions.com/about/legal/terms

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/intastellar-consents-solutions` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Under Intastellar CMP -> intro, configurate the privacy url & your language. Save it & you are good to go.

== Frequently Asked Questions ==
= How do I add a privacy policy? =
You can add a privacy policy by going to the settings page and adding the link to your privacy policy.

= How do I change the color of the banner? =
You can change the color of the banner by going to the branding page and choosing a color.

= How do I change the logo of the banner? =
You can change the logo of the banner by going to the branding page and uploading a logo.

= How do I change the placement of the banner? =
You can change the placement of the banner by going to the settings page and choosing a placement.

= How do I change the cookie notice text? =
You can change the cookie notice text by going to the settings page and changing the cookie notice text.

= How do I change the language of the banner? =
You can change the language of the banner by going to the intro page and choosing a language.

= How do I change the link to the privacy policy? =
You can change the link to the privacy policy by going to the privacy page and changing the link.

= How do I change the banner style? =
You can change the banner style by going to the settings page and choosing a banner style.

== Screenshots ==
1. This is the intro menu, where you can add a privacy policy & choose a language.
2. This is the branding menu, here you can choose what logo you want to use as well as choose your brand color.
3. The settings page helps you with the placement & cookie notice text, fullscreen mode & language.
4. The privacy menu here you can seperatly change the link / url to you privacy policy.
5. This is how the cookiebanner looks like in fullscreen mode.
6. This is how the cookiebanner looks like in compact mode.

== Changelog ==
= 3.3.9 =
Fixed logo path
= 3.3.8 =
Bug fixes, missing logo
= 3.3.7 =
General bug fixes
= 3.3.6 =
Added support for new languages & banner styles. General bug fixing
= 3.3.2 =
Added a new feature to the plugin, where you can upload or select a logo from the media library.
= 3.3.1 =
Fixed a bug where the cookie banner was not showing up & fixed small styling bugs.
= 3.3.0 =
We´ve updated the plugin to support the latest WordPress version, added support for Spanish language and added the possibility to choose a banner style.
= 3.2.2 =
Removed the advanced view settings because of a bug.
= 3.2.1 =
Fixed a bug where the cookie banner was not showing up.
= 3.2.0 =
Updated plugin to support root domain feature as well as the new cookie banner script.
= 3.0.1 =
Fixed a bug where the cookie banner was not showing up.
= 3.0.0 =
Updated the plugin to the latest Cookie Consent script.
= 2.1.1 =
Fixed some minor errors
= 2.1.0 =
Added the ability to add a companys name for the cookie overview list. Then we updated the cookie banner file link to a new one. For a structured changes.
= 2.0.0 =
In this Version we´ve redesigned the admin page for the plugin. We have categorized every thing, into: branding, intro, settings & privacy policy.
= 1.1.1 =
Fixed a bug where the main script was loaded inside the admin panel and update page.
= 1.1.0 =
Added on intro page the posibillity to add the Privacy Policy link & added on settings page the possibility to say you want start with the cookie settings page direct.
= 1.0.2 =
Added CCPA – California Consumer Privacy Act to the banner. its currently under dev and only showing the user a link to your CCPA policy.
= 1.0.1 =
Added a source parameter to the script to find out, wich plugin source the outgoing link is coming from.
= 1.0 =
Created the plugins menu as well as the settings page and the plugin in its self.

== Upgrade Notice ==
= 2.0.0 =
In this Version we´ve redesigned the admin page for the plugin. We have categorized every thing, into: branding, intro, settings & privacy policy.
= 1.0.2 =
Added CCPA – California Consumer Privacy Act to the banner. its currently under dev and only showing the user a link to your CCPA policy.
= 1.0.1 =
Added a source parameter to the script to find out, wich plugin source the outgoing link is coming from.
= 1.0 =
We've got updated the settings page, where you now can change your color, add a custom logo, add a link to your privacy policy and more.